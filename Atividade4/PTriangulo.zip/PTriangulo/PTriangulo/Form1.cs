﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double valA, valB, valC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                valA = double.Parse(txtA.Text);
                valB = double.Parse(txtB.Text);
                valC = double.Parse(txtC.Text);

                if (valA > 0 && valB > 0 && valC > 0)
                {
                    if ((Math.Abs(valB - valC) < valA && valB + valC > valA) && (Math.Abs(valA - valC) < valB && valA + valC > valB))
                    {
                        if (valA == valB && valB == valC)
                            MessageBox.Show("Triângulo Equilátero");
                        else if (valA == valB || valB == valC || valC == valA)
                            MessageBox.Show("Triângulo Isósceles");
                        else
                            MessageBox.Show("Triângulo Escaleno");
                    }
                    else
                        MessageBox.Show("Não é triângulo");
                }
                else
                    MessageBox.Show("Insira um valor maior do que zero!");

            }
            catch (Exception ex) {
                MessageBox.Show("Deu erro: " + ex.Message);
            }

            txtA.Focus();
        }
    }
}
