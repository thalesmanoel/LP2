﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] preco = new double[9, 3];
            string auxiliar;
            double soma = 0;
            double soma2;
            double media = 0;

            for (int i = 0; i < preco.GetLength(0); i++)
            {
                for (int j = 0; j < preco.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox(
                           $"Digite o preço do notebook {j + 1} da loja {i + 1}:",
                           "Entrada de dados"
                       );
                    if (!Double.TryParse(auxiliar, out preco[i, j]))
                    {
                        MessageBox.Show("Insira um valor válido!");
                        j--;
                    } else if ((double.Parse(auxiliar) >= 0)) 
                    {
                        soma += double.Parse(auxiliar);
                        media += double.Parse(auxiliar);

                        lstDados.Items.Add($"Notebook {j + 1} Loja {i + 1}: {auxiliar}");
                    } else
                    {
                        MessageBox.Show("Insira um valor válido!");
                        j--;
                    }


                }
                soma2 = soma / preco.GetLength(1);

                lstDados.Items.Add($"\n Media R$ {soma2.ToString("F2")}\n");
                lstDados.Items.Add("\n");
                soma = 0;
            }
            lstDados.Items.Add("\n----------------------------------\n");
            media = media / (preco.GetLength(0) * preco.GetLength(1));
            lstDados.Items.Add($"Media Geral Computadores R$ {media.ToString("F2")}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstDados.Items.Clear();
        }
    }
}
