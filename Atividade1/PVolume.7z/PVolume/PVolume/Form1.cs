﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double vlrRaio, vlrAltura;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtRaio.Text, out vlrRaio)) || (!double.TryParse(txtAltura.Text, out vlrAltura)))
            {
                MessageBox.Show("Valores inválidos");
                txtRaio.Focus();
            }
            else if (vlrRaio <= 0 || vlrAltura <= 0)
            {
                MessageBox.Show("Os valores devem ser maiores do que zero");
                txtRaio.Focus();
            }
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            
            if (!double.TryParse(txtRaio.Text, out vlrRaio))
                MessageBox.Show("raio inválido");
            else if (vlrRaio <= 0)
                MessageBox.Show("O raio deve ser maior do que zero");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            
            if (!double.TryParse(txtAltura.Text, out vlrAltura))
                MessageBox.Show("Altura inválida");
            else if (vlrAltura <= 0)
                MessageBox.Show("A altura deve ser maior do que zero");
            else
            {
                double volume;
                volume = Math.PI * Math.Pow(vlrRaio, 2) * vlrAltura;
                txtVolume.Text = volume.ToString("N2");

            }
        }
    }
}
