﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double val, num1, num2;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = double.Parse(txbxNumero1.Text);
                num2 = double.Parse(txbxNumero2.Text);
                val = num1 - num2;

                txbxResultado.Text = Convert.ToString(val);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Deu erro: " + ex.Message);
            }

            txbxNumero1.Focus();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = double.Parse(txbxNumero1.Text);
                num2 = double.Parse(txbxNumero2.Text);
                val = num1 * num2;

                txbxResultado.Text = Convert.ToString(val);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Deu erro: " + ex.Message);
            }

            txbxNumero1.Focus();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            

            try
            {
                num1 = double.Parse(txbxNumero1.Text);
                num2 = double.Parse(txbxNumero2.Text);

                if (num2 == 0)
                    MessageBox.Show("Insira um número superior a zero no Numero 2");
                else
                {
                    val = num1 / num2;
                    txbxResultado.Text = Convert.ToString(val);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Deu erro: " + ex.Message);
            }

            txbxNumero1.Focus();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txbxNumero1.Clear();
            txbxNumero2.Clear();
            txbxResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txbxNumero1_Validated(object sender, EventArgs e)
        {
            
                
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {

            try
            {
                num1 = double.Parse(txbxNumero1.Text);
                num2 = double.Parse(txbxNumero2.Text);
                val = num1 + num2;

                txbxResultado.Text = Convert.ToString(val);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Deu erro: " + ex.Message);
            }

            txbxNumero1.Focus();
        }
    }
}
