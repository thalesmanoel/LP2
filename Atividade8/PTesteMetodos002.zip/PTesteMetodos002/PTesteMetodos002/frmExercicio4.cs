﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos002
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            double salario, salarioBruto, gratificacao, producao;

            producao = float.Parse(txtProducao.Text);
            salario = float.Parse(txtSalario.Text);
            gratificacao = float.Parse(txtGratificacao.Text);
            salarioBruto = 0;

            if (salario > 7000) 
            {
                if (salario > 7000 && producao >= 150 && gratificacao > 0)
                {
                    salarioBruto = salario + salario * (0.05 * 1 + 0.1 * 1 + 0.1 * 1) + gratificacao;
                    MessageBox.Show("O salário bruto é: " + salarioBruto);
                }
                else
                    MessageBox.Show("Este funcionário não pode receber acima de R$7.000,00!");
            }
            else
            {
                if (producao >= 100)
                    if (producao >= 120)
                        if (producao >= 150)                    //     B          C         D
                            salarioBruto = salario + salario * (0.05 * 1 + 0.1 * 1 + 0.1 * 1) + gratificacao;
                        else
                            salarioBruto = salario + salario * (0.05 * 1 + 0.1 * 1 + 0.1 * 0) + gratificacao;
                    else
                        salarioBruto = salario + salario * (0.05 * 1 + 0.1 * 0 + 0.1 * 0) + gratificacao;
                else
                    salarioBruto = salario + salario * (0.05 * 0 + 0.1 * 0 + 0.1 * 0) + gratificacao;

                MessageBox.Show("O salário bruto é: R$" + salarioBruto);
            }
        }
    }
}
