﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos002
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnNumBranco_Click(object sender, EventArgs e)
        {
            int cont, qtdeEspaco;
            cont = 0;
            qtdeEspaco = 0;

            char[] vetor = rchtxtFrase.Text.ToCharArray();
            if (vetor.Length > 100)
                MessageBox.Show("Insira uma frase menor ou igual a 100 caracteres!");
            else
            {
                while (cont < vetor.Length)
                {
                    if (char.IsWhiteSpace(vetor[cont]))
                        qtdeEspaco++;

                    cont++;
                }
                MessageBox.Show("A quantidade de espaço em branco é: " + qtdeEspaco);
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            char[] vetor = rchtxtFrase.Text.ToCharArray();
            int qtdeLetraR = 0;
            if (vetor.Length > 100)
                MessageBox.Show("Insira uma frase menor ou igual a 100 caracteres!");
            else
                foreach (char c in vetor)
                {
                    if (c == 'R')
                        qtdeLetraR++;
                }
                if (qtdeLetraR > 0)
                    MessageBox.Show("A quantidade de letras R é: " + qtdeLetraR);
                else
                    MessageBox.Show("Não tem letra R");
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int cont, qtdePar = 0;
            char[] vetor = rchtxtFrase.Text.ToCharArray();

            if (vetor.Length > 100)
                MessageBox.Show("Insira uma frase menor ou igual a 100 caracteres!");
            else
                for (cont = 0; cont < (vetor.Length - 1); cont++)
                {
                if (vetor[cont] == vetor[cont + 1])
                    qtdePar++;
                }
                MessageBox.Show("A quantidade de pares de letras é: " + qtdePar);
        }
    }
}
