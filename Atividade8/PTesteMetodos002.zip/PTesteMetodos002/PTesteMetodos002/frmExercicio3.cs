﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos002
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string frase1 = txtFrase.Text;
            frase1 = frase1.Replace(" ", "").Replace(",", "").Replace(".", "").Replace("!", "").Replace("?", "");
            frase1 = frase1.ToUpper();
            
            char[] frase2 = frase1.ToCharArray();
            char[] reverseFrase = new char[frase2.Length];
            Array.Copy(frase2, reverseFrase, frase2.Length);
            Array.Reverse(reverseFrase);

            int cont = 0;

            if (frase2.Length > 50)
                MessageBox.Show("Insira uma frase menor do que 50 caracteres!");
            else
            {

                for (int i = 0; i < frase2.Length; i++)
                {
                    if (frase2[i] != reverseFrase[i])
                        break;
                    else
                        cont++;
                }

                if (cont == frase2.Length)
                    MessageBox.Show("É palíndromo");
                else
                    MessageBox.Show("Não é palíndromo");
            }
        }   
    }
}
