﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos002
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            float numero, n, h;
            numero = float.Parse(txtNumero.Text);

            h = 0;
            if (numero > 0)
            {
                for (int i = 0; i <= (numero-1); i++)
                {
                    n = i + 1;
                    h += (1/n);
                }

                MessageBox.Show("O valor de H é: " + h);
            }
            else
                MessageBox.Show("Insira um número maior do que 0");
        }
    }
}
