﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PTesteMetodos
{
    public partial class formExercicio5 : Form
    {
        public formExercicio5()
        {
            InitializeComponent();

            
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random randomNumero = new Random();

            try
            {
                int numero1, numero2, sorteio;
                numero1 = int.Parse(txtNumero1.Text);
                numero2 = int.Parse(txtNumero2.Text);


                if (numero1 < numero2)
                {
                    sorteio = randomNumero.Next(numero1, numero2);
                    MessageBox.Show("O numero sorteado é: " + sorteio);
                }

                else
                {
                    MessageBox.Show("O número 1 deve ser menor que o número 2");
                    txtNumero1.Clear();
                    txtNumero2.Clear();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Insira apenas números");
            }

        }
    }
}
