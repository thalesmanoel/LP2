﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int qtdeNumeros, cont;
            char[] vetor = rchtxtFrase.Text.ToCharArray();

            qtdeNumeros = 0;
            cont = 0;
            while (cont < vetor.Length)
            {
                if (char.IsNumber(vetor[cont]))
                    qtdeNumeros++;
                cont++;
            }

            if (qtdeNumeros > 0) 
                MessageBox.Show("Tem " + qtdeNumeros + " números");
            else
                MessageBox.Show("Não tem números");

        }

        private void btnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            int posicaoEspaco, cont;
            char[] vetor = rchtxtFrase.Text.ToCharArray();

            posicaoEspaco = 0;  
       
            for(cont = 0; cont < vetor.Length; cont++)
            {
                if (char.IsWhiteSpace(vetor[cont]))
                    posicaoEspaco = cont;
            }

            if (posicaoEspaco > 0)
                MessageBox.Show("A posição do caracter em branco é: " + (posicaoEspaco+1));
            else
                MessageBox.Show("Não tem caracter em branco");

        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            char[] vetor = rchtxtFrase.Text.ToCharArray();
            int qtdeLetras = 0;

            foreach (char c in vetor)
            {
                if (char.IsLetter(c))
                    qtdeLetras++;
            }
            if (qtdeLetras > 0)
                MessageBox.Show("A quantidade de letras é: " + qtdeLetras);
            else
                MessageBox.Show("Não tem letras");
        }

        
    }
}
