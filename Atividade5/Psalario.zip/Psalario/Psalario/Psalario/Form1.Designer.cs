﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxNome = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblAliquotaInss = new System.Windows.Forms.Label();
            this.lblAliquotaIrpf = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblDescontoInss = new System.Windows.Forms.Label();
            this.lblDescontoIrpf = new System.Windows.Forms.Label();
            this.txtDescontoInss = new System.Windows.Forms.TextBox();
            this.txtAliquotaIrpf = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtDescontoIrpf = new System.Windows.Forms.TextBox();
            this.txtAliquotaInss = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.numupdownFilhos = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numupdownFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // mskbxNome
            // 
            this.mskbxNome.Location = new System.Drawing.Point(365, 15);
            this.mskbxNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mskbxNome.Name = "mskbxNome";
            this.mskbxNome.Size = new System.Drawing.Size(393, 22);
            this.mskbxNome.TabIndex = 0;
            this.mskbxNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskbxNome_KeyPress);
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(365, 71);
            this.mskbxSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mskbxSalarioBruto.Mask = "00000.00";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(132, 22);
            this.mskbxSalarioBruto.TabIndex = 7;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(181, 20);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(166, 16);
            this.lblNome.TabIndex = 10;
            this.lblNome.Text = "Nome do(a) funcionário(a):";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(256, 75);
            this.lblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(87, 16);
            this.lblSalarioBruto.TabIndex = 11;
            this.lblSalarioBruto.Text = "Salario Bruto:";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(231, 142);
            this.lblNumFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(111, 16);
            this.lblNumFilhos.TabIndex = 12;
            this.lblNumFilhos.Text = "Número de filhos:";
            // 
            // lblAliquotaInss
            // 
            this.lblAliquotaInss.AutoSize = true;
            this.lblAliquotaInss.Location = new System.Drawing.Point(80, 356);
            this.lblAliquotaInss.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliquotaInss.Name = "lblAliquotaInss";
            this.lblAliquotaInss.Size = new System.Drawing.Size(93, 16);
            this.lblAliquotaInss.TabIndex = 13;
            this.lblAliquotaInss.Text = "Alíquota INSS:";
            // 
            // lblAliquotaIrpf
            // 
            this.lblAliquotaIrpf.AutoSize = true;
            this.lblAliquotaIrpf.Location = new System.Drawing.Point(79, 400);
            this.lblAliquotaIrpf.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliquotaIrpf.Name = "lblAliquotaIrpf";
            this.lblAliquotaIrpf.Size = new System.Drawing.Size(92, 16);
            this.lblAliquotaIrpf.TabIndex = 14;
            this.lblAliquotaIrpf.Text = "Alíquota IRPF:";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(72, 454);
            this.lblSalarioFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(100, 16);
            this.lblSalarioFamilia.TabIndex = 15;
            this.lblSalarioFamilia.Text = "Salário Familia:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(72, 508);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Salário Liquido:";
            // 
            // lblDescontoInss
            // 
            this.lblDescontoInss.AutoSize = true;
            this.lblDescontoInss.Location = new System.Drawing.Point(727, 366);
            this.lblDescontoInss.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoInss.Name = "lblDescontoInss";
            this.lblDescontoInss.Size = new System.Drawing.Size(102, 16);
            this.lblDescontoInss.TabIndex = 17;
            this.lblDescontoInss.Text = "Desconto INSS:";
            // 
            // lblDescontoIrpf
            // 
            this.lblDescontoIrpf.AutoSize = true;
            this.lblDescontoIrpf.Location = new System.Drawing.Point(729, 459);
            this.lblDescontoIrpf.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoIrpf.Name = "lblDescontoIrpf";
            this.lblDescontoIrpf.Size = new System.Drawing.Size(101, 16);
            this.lblDescontoIrpf.TabIndex = 18;
            this.lblDescontoIrpf.Text = "Desconto IRPF:";
            // 
            // txtDescontoInss
            // 
            this.txtDescontoInss.Enabled = false;
            this.txtDescontoInss.Location = new System.Drawing.Point(852, 362);
            this.txtDescontoInss.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescontoInss.Name = "txtDescontoInss";
            this.txtDescontoInss.Size = new System.Drawing.Size(132, 22);
            this.txtDescontoInss.TabIndex = 19;
            // 
            // txtAliquotaIrpf
            // 
            this.txtAliquotaIrpf.Enabled = false;
            this.txtAliquotaIrpf.Location = new System.Drawing.Point(196, 395);
            this.txtAliquotaIrpf.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAliquotaIrpf.Name = "txtAliquotaIrpf";
            this.txtAliquotaIrpf.Size = new System.Drawing.Size(132, 22);
            this.txtAliquotaIrpf.TabIndex = 20;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Enabled = false;
            this.txtSalarioFamilia.Location = new System.Drawing.Point(196, 450);
            this.txtSalarioFamilia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(132, 22);
            this.txtSalarioFamilia.TabIndex = 21;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(196, 505);
            this.txtSalLiq.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(132, 22);
            this.txtSalLiq.TabIndex = 22;
            // 
            // txtDescontoIrpf
            // 
            this.txtDescontoIrpf.Enabled = false;
            this.txtDescontoIrpf.Location = new System.Drawing.Point(852, 455);
            this.txtDescontoIrpf.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescontoIrpf.Name = "txtDescontoIrpf";
            this.txtDescontoIrpf.Size = new System.Drawing.Size(132, 22);
            this.txtDescontoIrpf.TabIndex = 23;
            // 
            // txtAliquotaInss
            // 
            this.txtAliquotaInss.Enabled = false;
            this.txtAliquotaInss.Location = new System.Drawing.Point(196, 353);
            this.txtAliquotaInss.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAliquotaInss.Name = "txtAliquotaInss";
            this.txtAliquotaInss.Size = new System.Drawing.Size(132, 22);
            this.txtAliquotaInss.TabIndex = 24;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(324, 226);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(271, 66);
            this.btnVerificar.TabIndex = 25;
            this.btnVerificar.Text = "Verificar desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // numupdownFilhos
            // 
            this.numupdownFilhos.Location = new System.Drawing.Point(361, 139);
            this.numupdownFilhos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numupdownFilhos.Name = "numupdownFilhos";
            this.numupdownFilhos.Size = new System.Drawing.Size(137, 22);
            this.numupdownFilhos.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.numupdownFilhos);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtAliquotaInss);
            this.Controls.Add(this.txtDescontoIrpf);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtAliquotaIrpf);
            this.Controls.Add(this.txtDescontoInss);
            this.Controls.Add(this.lblDescontoIrpf);
            this.Controls.Add(this.lblDescontoInss);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIrpf);
            this.Controls.Add(this.lblAliquotaInss);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.mskbxNome);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numupdownFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblAliquotaInss;
        private System.Windows.Forms.Label lblAliquotaIrpf;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblDescontoInss;
        private System.Windows.Forms.Label lblDescontoIrpf;
        private System.Windows.Forms.TextBox txtDescontoInss;
        private System.Windows.Forms.TextBox txtAliquotaIrpf;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtDescontoIrpf;
        private System.Windows.Forms.TextBox txtAliquotaInss;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.NumericUpDown numupdownFilhos;
    }
}

