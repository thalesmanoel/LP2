﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salBruto, descInss, descIprf, numFilhos, descSalFam, salLiquido;

        private void mskbxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
 
            if (char.IsDigit(e.KeyChar) || char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caractere inválido");
                SendKeys.Send("{BACKSPACE}");
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {   
                salBruto = double.Parse(mskbxSalarioBruto.Text);
                numFilhos = double.Parse(numupdownFilhos.Text);
                //Cálculo para INSS
                if (salBruto <= 800.47)
                {
                    descInss = salBruto * 0.0765;
                    txtAliquotaInss.Text = "7,65%";
                }
                else if (salBruto < 1050)
                {
                    descInss = salBruto * 0.0865;
                    txtAliquotaInss.Text = "8,65%";
                }
                else if (salBruto < 1400.77)
                {
                    descInss = salBruto * 0.09;
                    txtAliquotaInss.Text = "9%";
                }
                else if (salBruto < 2801.56)
                {
                    descInss = salBruto * 0.11;
                    txtAliquotaInss.Text = "11%";
                }
                else
                {
                    descInss = 308.17;
                    txtAliquotaInss.Text = "308.17";
                }

                txtDescontoInss.Text = Convert.ToString(descInss);

                //Cálculo para IPRF
                if (salBruto <= 1257.12)
                {
                    descIprf = 0;
                    txtAliquotaIrpf.Text = "0";
                }
                else if (salBruto < 2512.08)
                {
                    descIprf = salBruto * 0.15;
                    txtAliquotaIrpf.Text = "15%";
                }
                else
                {
                    descIprf = salBruto * 0.275;
                    txtAliquotaIrpf.Text = "27,5%";
                }

                txtDescontoIrpf.Text = Convert.ToString(descIprf);

                //Cálculo para salário familia
                if (numFilhos == 0)
                {
                    descSalFam = 0;
                    txtSalarioFamilia.Text = Convert.ToString(descSalFam);

                }
                else
                {
                    if (salBruto <= 435.52)
                    {
                        descSalFam = numFilhos * 22.33;
                        txtSalarioFamilia.Text = Convert.ToString(descSalFam);
                    }
                    else if (salBruto < 654.61)
                    {
                        descSalFam = numFilhos * 15.74;
                        txtSalarioFamilia.Text = Convert.ToString(descSalFam);

                    }
                    else
                    {
                        descSalFam = 0;
                        txtSalarioFamilia.Text = Convert.ToString(descSalFam);

                    }


                }

                //Cálculo salário liquido
                salLiquido = salBruto - descInss - descIprf + descSalFam;
                txtSalLiq.Text = Convert.ToString(salLiquido);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Deu erro: " + ex.Message);
            }

        }
    }
}
