﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteMatriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = 9;
            n = 10 * 10;
            string auxiliar;
            string[,] questoes = new string[n, 10];
            string[] gabarito = { "A", "D", "E", "B", "A", "C", "E", "A", "B", "C"};


            for (int i = 0; i < questoes.GetLength(0); i++)
            {
                for (int j = 0; j < questoes.GetLength(1); j++)
                {
                    do
                    {
                        auxiliar = Interaction.InputBox(
                            $"Digite a resposta da questão {j + 1} do aluno {i + 1}:",
                            "Entrada de dados"
                        );

                        auxiliar = auxiliar.ToUpper();

                        if (auxiliar != "A" && auxiliar != "B" && auxiliar != "C" && auxiliar != "D" && auxiliar != "E")
                            MessageBox.Show("Insira uma resposta que seja A, B, C, D ou E");
                        
                    } while (auxiliar != "A" && auxiliar != "B" && auxiliar != "C" && auxiliar != "D" && auxiliar != "E");

                    questoes[i, j] = auxiliar;
                }
            }

            for (int i = 0; i < questoes.GetLength(0); i++)
            {
                for (int j = 0; j < questoes.GetLength(1); j++)
                {
                    if (gabarito[j] == questoes[i, j])
                    {
                        lstbxAlunos.Items.Add($"Aluno {i + 1} inseriu resposta: {questoes[i, j]} na questão {j + 1}. Resposta correta!");
                    }
                    else
                    {
                        lstbxAlunos.Items.Add($"Aluno {i + 1} inseriu resposta: {questoes[i, j]} na questão {j + 1}. Resposta incorreta!");
                    }
                }
            }
        }
    }
}
