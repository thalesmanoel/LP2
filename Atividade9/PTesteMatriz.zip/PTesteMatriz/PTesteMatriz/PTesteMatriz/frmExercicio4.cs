﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteMatriz
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] caracteres = new int[9];
            string[] nomes = new string[9];
            int n = 9;
            string auxiliar;

            for (int i = 0; i < n; i++)
            {
                auxiliar = Interaction.InputBox(
                    $"Digite o {i + 1}° nome",
                    "Entrada de dados: "
                    );
                nomes[i] = auxiliar;
                caracteres[i] = auxiliar.Replace(" ", "").Length;
            }

            for (int i = 0; i < n; i++)
                lstbxNomes.Items.Add("O nome é:" + nomes[i] + ", e tem " + caracteres[i] + " caracteres");
        }
    }
}
