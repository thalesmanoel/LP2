﻿namespace PTesteMatriz
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnComeçar2 = new System.Windows.Forms.Button();
            this.lstbxAlunos = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnComeçar2
            // 
            this.btnComeçar2.Location = new System.Drawing.Point(53, 136);
            this.btnComeçar2.Name = "btnComeçar2";
            this.btnComeçar2.Size = new System.Drawing.Size(170, 145);
            this.btnComeçar2.TabIndex = 0;
            this.btnComeçar2.Text = "Começar";
            this.btnComeçar2.UseVisualStyleBackColor = true;
            this.btnComeçar2.Click += new System.EventHandler(this.button1_Click);
            // 
            // lstbxAlunos
            // 
            this.lstbxAlunos.FormattingEnabled = true;
            this.lstbxAlunos.ItemHeight = 16;
            this.lstbxAlunos.Location = new System.Drawing.Point(302, 12);
            this.lstbxAlunos.Name = "lstbxAlunos";
            this.lstbxAlunos.Size = new System.Drawing.Size(595, 692);
            this.lstbxAlunos.TabIndex = 1;
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1340, 731);
            this.Controls.Add(this.lstbxAlunos);
            this.Controls.Add(this.btnComeçar2);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnComeçar2;
        private System.Windows.Forms.ListBox lstbxAlunos;
    }
}