﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for(int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox(
                    $"Digite um número {i+1}°",
                    "Entrada de dados: "
                    );
                if(!int.TryParse( auxiliar, out vetor[i]) )
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse( vetor ); //inverte o vetor

            auxiliar = "";

            foreach(int i in vetor)
                auxiliar += i + "\n";

            MessageBox.Show( auxiliar );
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";

            ArrayList nomes = new ArrayList();
            nomes.Add("Ana"); nomes.Add("André"); nomes.Add("Débora"); nomes.Add("Fátima"); nomes.Add("João"); nomes.Add("Janete"); nomes.Add("Otávio"); nomes.Add("Marcelo");
            nomes.Add("Pedro"); nomes.Add("Thais");

            nomes.Remove("Otávio");

            foreach(string i in nomes)
                auxiliar += i + "\n";
            MessageBox.Show( auxiliar );
                
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double soma, media;
            string auxiliar;
            

            for(int i = 0; i < 20; i++)
            {
                soma = 0;
                media = 0;

                for (int j = 0; j < 3; j++) 
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ");
                    if ((!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10))
                    {
                        MessageBox.Show("Insira um valor inválido!");
                        j--;
                    }
                    else
                        soma += notas[i, j];
                }
                media = soma / 3;
                MessageBox.Show($"Aluno {i+1}: Média: {media}");
            }
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();

            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();

            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();

                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }
    }
}
